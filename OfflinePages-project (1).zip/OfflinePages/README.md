# OfflinePages 1.0

Android application prototype using Kotlin + Android WebView. The UI is bundled locally and works without a network connection. Folder/page metadata and theme are stored in WebView localStorage. Saved pages are stored as MHTML archives in the app's private files directory.

## Build

Requires JDK 17 and Android SDK platform 35/build-tools 35.0.0, plus Gradle 8.9+.

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK using GitHub Actions

1. Create a GitHub repository and upload this project.
2. Open Actions → Build OfflinePages APK → Run workflow.
3. Download the `OfflinePages-debug-apk` artifact after the workflow finishes. Extract `app-debug.apk` and install it on Android.

## Limitations

The downloader uses Android WebView's `saveWebArchive` (MHTML). It captures the rendered page and resources WebView has loaded, but cannot guarantee complete offline behavior for server-backed applications, authenticated pages, DRM video, cross-origin content blocked by the site, streaming media, or scripts that require a live backend. The capture currently waits 1.8 seconds after the main document finishes loading; complex sites may need a longer wait or a user-controlled capture-ready step. MHTML support and playback behavior vary by site and Android WebView version.
