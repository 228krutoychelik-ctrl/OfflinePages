package com.offlinepages.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.widget.FrameLayout
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var ui: WebView
    private lateinit var capture: WebView
    private lateinit var root: FrameLayout
    private var pendingTitle = ""
    private var pendingFolder = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        ui = WebView(this)
        capture = WebView(this)
        configure(ui)
        configure(capture)
        capture.visibility = android.view.View.GONE
        root.addView(ui, FrameLayout.LayoutParams(-1, -1))
        root.addView(capture, FrameLayout.LayoutParams(1, 1))
        setContentView(root)
        ui.addJavascriptInterface(Bridge(), "Native")
        ui.loadUrl("file:///android_asset/index.html")
        capture.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == "about:blank") return
                // Give images, stylesheets and delayed page resources a moment to settle.
                ui.postDelayed({
                    val dir = File(filesDir, "archives").apply { mkdirs() }
                    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    val target = File(dir, "page_$stamp.mhtml").absolutePath
                    capture.saveWebArchive(target, false) { path ->
                        capture.loadUrl("about:blank")
                        val result = JSONObject().apply {
                            put("ok", !path.isNullOrBlank() && File(path).exists())
                            put("path", path ?: "")
                            put("title", pendingTitle)
                            put("folder", pendingFolder)
                            put("date", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()))
                        }
                        ui.evaluateJavascript("window.onArchiveSaved(${JSONObject.quote(result.toString())})", null)
                    }
                }, 1800)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(web: WebView) {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
    }

    inner class Bridge {
        @JavascriptInterface fun download(url: String, title: String, folder: String) {
            runOnUiThread {
                val normalized = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
                pendingTitle = title
                pendingFolder = folder
                capture.loadUrl(normalized)
                ui.evaluateJavascript("window.setDownloadState('Загружаю страницу…')", null)
            }
        }
        @JavascriptInterface fun openArchive(path: String) {
            runOnUiThread {
                val f = File(path)
                if (f.exists() && f.canonicalPath.startsWith(filesDir.canonicalPath)) {
                    ui.loadUrl(android.net.Uri.fromFile(f).toString())
                }
            }
        }
        @JavascriptInterface fun home() { runOnUiThread { ui.loadUrl("file:///android_asset/index.html") } }
        @JavascriptInterface fun deleteArchive(path: String): Boolean {
            return try {
                val f = File(path)
                f.canonicalPath.startsWith(File(filesDir, "archives").canonicalPath) && f.delete()
            } catch (_: Exception) { false }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::ui.isInitialized && ui.url?.startsWith("file:///android_asset/") == false) {
            ui.loadUrl("file:///android_asset/index.html")
        } else super.onBackPressed()
    }
}
